const { Op } = require("sequelize");
// Doing this to have like Words Search

const { City }=require('../models/index');
//doing this will put all the models in the models used in that folder


class CityRepository{

    async createCity({name}){
        try {
            const city=await City.create({
                name:name // first name represent the model property "name"
            });
            return city;
        } catch (error){
            console.log("Something went wrong in the repo-layer");
            throw {error};
        }
    }

    async deleteCity(cityId){
        try {
            await City.destroy({
                where:{
                    id : cityId
                }
            });
            return true;
        } catch (error) {
            console.log("Something went wrong in the repo-layer");
            throw {error};
        }
    }

    async updateCity(cityId,data){
        try {
            // The below approach also works but will not return updated object
            // if we are using Pg then returning: true can be used, else not
            // const city = await City.update(data, {
            //     where: {
            //         id: cityId
            //     },
            //      
            // });
            // for getting updated data in mysql we use the below approach
            const city = await City.findByPk(cityId);
            city.name = data.name;
            await city.save();
            return city;
        } catch (error) {
            console.log("Something went wrong in the repo-layer");
            throw {error};
        }
    }

    async getCity(cityId){
        try {
            // const city=await City.findone({
            //     where:{
            //         id: cityId
            //     }
            // }) or
            const city = await City.findByPk(cityId);//above and this function is same
            return city;
        } catch (error) {
            console.log("Something went wrong in the repo-layer");
            throw {error};
        }
    }

    async getAllcities(filter){//filter can be empty also
        try {
            if(filter.name){
                const cities = await City.findAll({
                    where: {
                        name: {
                            [Op.startsWith]: filter.name // this will give all the cities whose name starts with the filter name
                        }
                    }
                });
                return cities;
            }
            const cities = await City.findAll();
            return cities;
        } catch (error) {
            console.log("Something went wrong in the repo-layer");
            throw {error};
        }
    }

}

module.exports= CityRepository;