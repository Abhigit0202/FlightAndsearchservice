//database setup check
 